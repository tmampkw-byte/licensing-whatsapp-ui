export const metadata = {
  title: 'نظام التراخيص وداشبورد واتساب — نسخة تجريبية',
  description: 'UI تجريبية RTL لموقعين متكاملين (إدارة تراخيص + واتساب)',
};
import './globals.css';
import React from 'react';
export default function RootLayout({ children }){
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-gray-50 text-gray-900">{children}</body>
    </html>
  );
}
