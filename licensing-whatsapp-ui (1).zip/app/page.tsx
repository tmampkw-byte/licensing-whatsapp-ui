'use client';
import React, {useMemo, useState} from 'react';
import { motion } from 'framer-motion';
import { Section } from '@/components/Section';

type Company = { id:number; name:string; cr:string; phone:string; delegates:string[]; licensesExpiring:number; };
type License = { id:number; company:number; type:string; number:string; issue:string; expiry:string; status:'ساري'|'منتهي' };
type Employee = { id:number; company:number; name:string; civil:string; passport:string; dl:string; dlExpiry:string };

const LICENSE_TYPES = ['ترخيص تجاري','ترخيص مطافي','ترخيص إعلان','ترخيص صحة','ترخيص غذاء','ترخيص تربية إبل','ترخيص تربية أغنام','ترخيص مزرعة','ترخيص عقار','رخصة استيراد','اعتماد توقيع شؤون','اعتماد توقيع مرور','اعتماد توقيع جمارك'];

const demoCompanies:Company[] = [
  { id:1, name:'شركة الخليج للتجارة', cr:'12345', phone:'+96550000001', delegates:['أحمد'], licensesExpiring:2 },
  { id:2, name:'مزارع الوطن', cr:'67890', phone:'+96550000002', delegates:['سالم','نورة'], licensesExpiring:1 },
  { id:3, name:'للإعلان المبتكر', cr:'54321', phone:'+96550000003', delegates:[], licensesExpiring:0 },
];
const demoLicenses:License[] = [
  { id:100, company:1, type:'ترخيص تجاري', number:'C-2023-001', issue:'2024-01-01', expiry:'2025-12-31', status:'ساري' },
  { id:101, company:1, type:'ترخيص مطافي', number:'F-8877', issue:'2024-09-15', expiry:'2025-09-14', status:'ساري' },
  { id:102, company:2, type:'ترخيص تربية إبل', number:'CAM-11', issue:'2023-10-10', expiry:'2025-10-09', status:'ساري' },
  { id:103, company:2, type:'ترخيص صحة', number:'H-430', issue:'2024-02-01', expiry:'2025-01-31', status:'منتهي' },
];
const demoEmployees:Employee[] = [
  { id:1, company:1, name:'محمد علي', civil:'284011234567', passport:'P998877', dl:'DL2211', dlExpiry:'2026-03-01' },
  { id:2, company:1, name:'وليد سالم', civil:'285020123456', passport:'P112233', dl:'-', dlExpiry:'-' },
  { id:3, company:2, name:'حسن يوسف', civil:'290101223344', passport:'P445566', dl:'DL4433', dlExpiry:'2025-11-30' },
];
const expiringSoon = (dateStr:string)=>{
  const d = new Date(dateStr); const now = new Date();
  const diffDays = Math.ceil((d.getTime()-now.getTime())/(1000*60*60*24));
  return diffDays <= 30;
};

export default function Page(){
  const [tab, setTab] = useState<'site1'|'site2'>('site1');
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 bg-white/80 backdrop-blur border-b">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="font-semibold">نظام التراخيص & واتساب</span>
            <span className="pill">نسخة تجريبية</span>
          </div>
          <div className="flex items-center gap-2">
            <input placeholder="بحث سريع…" className="w-56" />
            <button className="btn" aria-label="settings">الإعدادات</button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-2 gap-2 rounded-2xl overflow-hidden border bg-white mb-6">
          <button onClick={()=>setTab('site1')} className={`px-4 py-2 text-right ${tab==='site1'?'bg-gray-100 font-semibold':''}`}>الموقع الأول: إدارة الشركات والتراخيص</button>
          <button onClick={()=>setTab('site2')} className={`px-4 py-2 text-right ${tab==='site2'?'bg-gray-100 font-semibold':''}`}>الموقع الثاني: داشبورد واتساب</button>
        </div>

        {tab==='site1' && (
          <div className="space-y-6">
            <motion.div initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} transition={{duration:0.3}} className="grid md:grid-cols-3 gap-6">
              <Section title="ملخص سريع" desc="نظرة عامة على التراخيص والاشتراكات والتنبيهات">
                <div className="grid grid-cols-3 gap-3">
                  <div className="card"><div className="card-h"><div className="text-base font-medium">تراخيص سارية</div></div><div className="card-c text-3xl font-bold">{demoLicenses.filter(l=>l.status==='ساري').length}</div></div>
                  <div className="card"><div className="card-h"><div className="text-base font-medium">تنتهي خلال 30 يوم</div></div><div className="card-c text-3xl font-bold">{demoLicenses.filter(l=>expiringSoon(l.expiry)).length}</div></div>
                  <div className="card"><div className="card-h"><div className="text-base font-medium">اشتراكات نشطة</div></div><div className="card-c text-3xl font-bold">{demoCompanies.length}</div></div>
                </div>
                <div className="separator"></div>
                <div className="flex items-center justify-between text-sm">
                  <div className="text-gray-600">جدول التنبيهات: 90/60/30/14/7/3/0 يوم</div>
                  <div className="flex gap-2"><button className="btn">تعديل القوالب</button><button className="btn btn-primary">إرسال اختبار</button></div>
                </div>
              </Section>

              <Section title="إضافة/تعديل شركة" desc="البيانات الأساسية ومندوبي الاتصال">
                <div className="grid gap-3">
                  <div className="grid gap-2"><label>اسم الشركة</label><input placeholder="مثال: شركة الخليج للتجارة"/></div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="grid gap-2"><label>الرقم التجاري / السجل</label><input placeholder="CR Number"/></div>
                    <div className="grid gap-2"><label>جوال/واتساب</label><input placeholder="+9655…"/></div>
                  </div>
                  <div className="grid gap-2"><label>العنوان</label><textarea placeholder="المنطقة، الشارع، المبنى…"/></div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="grid gap-2"><label>مندوب</label><input placeholder="اسم المندوب"/></div>
                    <div className="grid gap-2"><label>واتساب المندوب</label><input placeholder="+965…"/></div>
                  </div>
                  <div className="flex items-center gap-2"><input type="checkbox" defaultChecked id="optin"/><label htmlFor="optin">تفويض الإرسال على واتساب (Opt‑in)</label></div>
                  <div className="flex gap-2 justify-end"><button className="btn">حفظ مسودة</button><button className="btn btn-primary">حفظ الشركة</button></div>
                </div>
              </Section>

              <Section title="إضافة ترخيص" desc="ربط ترخيص بنوعه وتواريخ الانتهاء وإرفاق مستندات">
                <div className="grid gap-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="grid gap-2"><label>الشركة</label><select><option>اختر شركة</option>{demoCompanies.map(c=> <option key={c.id} value={String(c.id)}>{c.name}</option>)}</select></div>
                    <div className="grid gap-2"><label>نوع الترخيص</label><select><option>اختر النوع</option>{LICENSE_TYPES.map(t=> <option key={t} value={t}>{t}</option>)}</select></div>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div className="grid gap-2"><label>رقم الترخيص</label><input placeholder="مثال: C-2025-009"/></div>
                    <div className="grid gap-2"><label>تاريخ الإصدار</label><input type="date"/></div>
                    <div className="grid gap-2"><label>تاريخ الانتهاء</label><input type="date"/></div>
                  </div>
                  <div className="flex items-center gap-2"><button className="btn">رفع مرفقات</button><span className="text-xs text-gray-500">PDF, JPG, PNG</span></div>
                  <div className="flex gap-2 justify-end"><button className="btn">إضافة ترخيص آخر</button><button className="btn btn-primary">حفظ الترخيص</button></div>
                </div>
              </Section>
            </motion.div>

            <Section title="قائمة التراخيص" desc="بحث وفرز حسب النوع والحالة والانتهاء">
              <div className="flex flex-wrap items-center gap-2 mb-3">
                <span className="pill">الكل</span>
                <select className="w-48"><option>نوع الترخيص</option>{LICENSE_TYPES.map(t=> <option key={t}>{t}</option>)}</select>
                <select className="w-36"><option>الحالة</option><option>ساري</option><option>منتهي</option></select>
                <input placeholder="ابحث برقم الترخيص…" className="w-64"/>
                <div className="ms-auto flex gap-2"><button className="btn">تصدير CSV</button><button className="btn btn-primary">إنشاء تذكير</button></div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="text-right text-gray-600"><th className="py-2">الشركة</th><th>النوع</th><th>رقم الترخيص</th><th>الإصدار</th><th>الانتهاء</th><th>الحالة</th></tr></thead>
                  <tbody>
                    {demoLicenses.map(l=>{
                      const c = demoCompanies.find(x=>x.id===l.company);
                      const soon = expiringSoon(l.expiry);
                      return (
                        <tr key={l.id} className={soon?'bg-amber-50/60':''}>
                          <td className="py-2">{c?.name}</td>
                          <td>{l.type}</td>
                          <td>{l.number}</td>
                          <td>{new Date(l.issue).toLocaleDateString('ar-KW')}</td>
                          <td>{new Date(l.expiry).toLocaleDateString('ar-KW')} {soon and ''}</td>
                          <td><span className={`badge ${l.status==='ساري'?'badge-green':'badge-gray'}`}>{l.status}</span></td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </Section>

            <Section title="العمّال" desc="إدارة بيانات العاملين والوثائق">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="grid gap-3">
                  <div className="grid gap-2"><label>اسم العامل</label><input placeholder="الاسم الثلاثي"/></div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="grid gap-2"><label>الرقم المدني</label><input placeholder="000000000000"/></div>
                    <div className="grid gap-2"><label>رقم الجواز</label><input placeholder="P123456"/></div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="grid gap-2"><label>رخصة القيادة</label><input placeholder="DL-123"/></div>
                    <div className="grid gap-2"><label>انتهاء الرخصة</label><input type="date"/></div>
                  </div>
                  <div className="flex items-center gap-2"><button className="btn">مرفقات</button></div>
                  <div className="flex gap-2 justify-end"><button className="btn">مسودة</button><button className="btn btn-primary">حفظ العامل</button></div>
                </div>
                <div className="border rounded-2xl p-4 bg-white">
                  <h4 className="font-semibold mb-2">قائمة العمال</h4>
                  <div className="space-y-2 max-h-64 overflow-auto">
                    {demoEmployees.map(e=> (
                      <div key={e.id} className="flex items-center justify-between rounded-xl border p-3 bg-gray-50">
                        <div>
                          <div className="font-medium">{e.name}</div>
                          <div className="text-xs text-gray-600">مدني: {e.civil} — جواز: {e.passport}</div>
                        </div>
                        <div className="text-xs text-gray-600">ر.القيادة: {e.dl} — انتهاء: {e.dlExpiry}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </Section>
          </div>
        )}

        {tab==='site2' && (
          <div className="space-y-6">
            <Section title="الاتصال بواتساب" desc="اختر طريقة الربط: Cloud API الرسمي أو جلسة QR">
              <div className="grid gap-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="card"><div className="card-h"><div className="font-medium">Cloud API</div></div><div className="card-c text-sm text-gray-600">موثوق + قوالب معتمدة + Webhooks</div></div>
                  <div className="card"><div className="card-h"><div className="font-medium">جلسة QR</div></div><div className="card-c text-sm text-gray-600">ربط سريع عبر مسح — يحتاج مراقبة الجلسة</div></div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="grid gap-2"><label>رقم الإرسال</label><input placeholder="رقم واتساب الأعمال"/></div>
                  <div className="grid gap-2"><label>Webhook URL</label><input placeholder="https://…/wa/webhook"/></div>
                </div>
                <div className="flex items-center gap-2"><input type="checkbox" id="sandbox"/><label htmlFor="sandbox">وضع الاختبار</label></div>
                <div className="flex gap-2 justify-end"><button className="btn">حفظ</button><button className="btn btn-primary">بدء الربط</button></div>
              </div>
            </Section>

            <Section title="صندوق الوارد" desc="عرض المحادثات الواردة وتصنيفها وتحويلها">
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-1 border rounded-2xl overflow-hidden bg-white">
                  <div className="p-3 border-b flex gap-2"><input placeholder="بحث…" className="flex-1"/></div>
                  <div className="max-h-64 overflow-auto">
                    {demoCompanies.map(c=> (
                      <div key={c.id} className="p-3 hover:bg-gray-50 cursor-pointer flex items-center justify-between border-b">
                        <div>
                          <div className="font-medium">{c.name}</div>
                          <div className="text-xs text-gray-600">{c.phone}</div>
                        </div>
                        <span className="badge badge-amber">{c.licensesExpiring} إنذارات</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="col-span-2 border rounded-2xl flex flex-col bg-white">
                  <div className="p-3 border-b flex items-center justify-between">
                    <div>
                      <div className="font-medium">شركة الخليج للتجارة</div>
                      <div className="text-xs text-gray-600">يرتبط بـ 3 تراخيص و 2 عمّال</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <label className="text-sm">تشغيل البوت</label>
                      <input type="checkbox" defaultChecked />
                      <div className="w-px h-6 bg-gray-200"></div>
                      <select className="w-40"><option>تعيين لموظف</option><option>وكيل — سارة</option><option>وكيل — يوسف</option></select>
                      <button className="btn">تحويل</button>
                    </div>
                  </div>
                  <div className="flex-1 p-4 space-y-3 overflow-auto">
                    <div className="max-w-[70%] ms-auto bg-blue-600 text-white rounded-2xl p-3 text-sm">مرحبًا 👋 تم تسجيل شركتكم. هل ترغبون بمراجعة التراخيص القريبة من الانتهاء؟</div>
                    <div className="max-w-[70%] bg-gray-100 rounded-2xl p-3 text-sm">نعم، أرسل لي تفاصيل ترخيص المطافي ورخصة الصحة.</div>
                    <div className="max-w-[70%] ms-auto bg-blue-600 text-white rounded-2xl p-3 text-sm">ترخيص المطافي ينتهي في 14/09/2025 — أرسل 1 لتجديده، 2 لعرض المتطلبات.</div>
                  </div>
                  <div className="p-3 border-t flex items-center gap-2">
                    <input placeholder="اكتب رسالة…" className="flex-1"/>
                    <button className="btn">صورة</button>
                    <button className="btn">موقع</button>
                    <button className="btn">مستند</button>
                    <button className="btn btn-primary">إرسال</button>
                  </div>
                </div>
              </div>
            </Section>

            <Section title="قواعد البوت وردود سريعة" desc="إجابات تلقائية وخيارات التحويل للبشري">
              <div className="grid gap-3">
                <div className="grid md:grid-cols-2 gap-3">
                  <div className="grid gap-2"><label>نية (Intent)</label><input placeholder="مثال: استعلام_انتهاء_ترخيص"/></div>
                  <div className="grid gap-2"><label>كلمات مفتاحية</label><input placeholder="انتهاء، ترخيص، تجديد…"/></div>
                </div>
                <div className="grid gap-2"><label>نص الرد</label><textarea placeholder="مثال: ترخيص {نوع} ينتهي بتاريخ {تاريخ}. هل ترغب بفتح طلب تجديد؟" /></div>
                <div className="flex items-center gap-2"><input type="checkbox" id="handoff"/><label htmlFor="handoff">تحويل للبشري عند عدم التأكد</label></div>
                <div className="flex gap-2 justify-end"><button className="btn">رد سريع جديد</button><button className="btn btn-primary">حفظ القاعدة</button></div>
              </div>
            </Section>
          </div>
        )}
      </main>

      <footer className="container mx-auto px-4 py-10 text-center text-sm text-gray-600">
        © {new Date().getFullYear()} — واجهة تجريبية لنظام التراخيص وداشبورد واتساب
      </footer>
    </div>
  );
}
