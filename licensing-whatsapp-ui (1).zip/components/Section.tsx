import React from 'react';
export function Section({title,desc,children}:{title:string,desc?:string,children?:React.ReactNode}){
  return (
    <div className="card">
      <div className="card-h">
        <div className="text-lg font-semibold">{title}</div>
        {desc && <div className="text-sm text-gray-500">{desc}</div>}
      </div>
      <div className="card-c space-y-4">{children}</div>
    </div>
  );
}
