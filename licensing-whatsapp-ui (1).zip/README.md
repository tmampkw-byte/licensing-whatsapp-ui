# نظام التراخيص وداشبورد واتساب — نسخة UI تجريبية

واجهة عربية RTL (Next.js + Tailwind) لموقعين متكاملين: إدارة التراخيص + داشبورد واتساب.

## التشغيل المحلي
```bash
npm i
npm run dev
```
يفتح على http://localhost:3000

## النشر السريع (Vercel)
1) أنشئ حساب على https://vercel.com
2) `Import Project` ثم ارفع هذا المجلد أو ادفعه إلى GitHub ثم اربطه.
3) لا حاجة لإعدادات خاصة — Tailwind و Next جاهزين.
4) بعد البناء ستحصل على رابط مثل: https://your-project.vercel.app

> لاحقًا يمكن إضافة صفحات API وربط قواعد البيانات وواتساب Cloud API.
